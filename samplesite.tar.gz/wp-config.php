<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/documentation/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'getfylig_wp71' );

/** Database username */
define( 'DB_USER', 'GFAAdmin' );

/** Database password */
define( 'DB_PASSWORD', '56xm19TjMv8mTl' );

/** Database hostname */
define( 'DB_HOST', 'gfa-db-server.mysql.database.azure.com' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'k7:-rGp:99e%u;gbC9J]{mys=Yr|!Pfw#%`*]z#|45n2{kf,y|R_u|Ie?4udbuJa');
define('SECURE_AUTH_KEY',  '5I-]$X/b|==Li5@=OzkKYx>9GuNDQ#y},s`S^|&TlA#-$+X V7e}|{oi~!tZhMDv');
define('LOGGED_IN_KEY',    '_5fz;tWtNq4DX+l>H.5xR=s2rO&i)I:AfBcb%3K<x}H43[(PD=~{+W3op$t:/:mo');
define('NONCE_KEY',        '.;um,H:4u#aZX]lN?PwT{uR1.`.pQo@@58LR=-CQ-RT##_m;1k7ZMXB9|=KI:}Tv');
define('AUTH_SALT',        'l,YUkpjn5O&!|G~&Wna,)&5_}Bg}UP-(}TrK0uDeJrz|;e&bkG%gZ8$Dn&W@}=j7');
define('SECURE_AUTH_SALT', 'R|)-m3iICd&}KXgWxx^dgKf-py1;Xg|@c^F[:Y`EY1,M_U4xprDY[ki]:~ lM!hE');
define('LOGGED_IN_SALT',   '7$M~/F(qKx,l,BxDdFszK+7Xtui 1~`-|w?;HsjfE%h+|n~MPw5Q_MYLa0wQGR0*');
define('NONCE_SALT',       'K!p(yp~)-oe)6$VAAE(uug4Vy@[?E^<C{RJy0:V-^:4)|044)#:Bs9P+d4GpG6a;');

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/documentation/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
