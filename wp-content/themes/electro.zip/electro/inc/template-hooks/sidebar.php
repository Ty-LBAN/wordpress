<?php
/**
 * Electro Sidebar Hooks
 *
 * @since 2.0
 */
/*
 * Sidebar
 */
add_action( 'electro_sidebar', 'electro_get_sidebar', 10 );